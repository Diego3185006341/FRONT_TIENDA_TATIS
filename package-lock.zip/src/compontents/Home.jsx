import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, Nav, Container, Row, Col, Card } from 'react-bootstrap';
import { BiCart } from 'react-icons/bi';
import './Home.css'; // Asegúrate de reemplazar con la ruta correcta

const Home = () => {
  const productos = [
    { id: 1, nombre: 'Cartulina negra', precio: 19.99, imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_8b-Hl8kXAxojcurWG3awZOFJLqw55l99nQ&usqp=CAU' },
    { id: 2, nombre: 'Caja de colores', precio: 29.99, imagen: 'https://panamericana.vtexassets.com/arquivos/ids/417378-800-auto?v=637729599795300000&width=800&height=auto&aspect=true'},
    { id: 3, nombre: 'Cuadernos', precio: 39.99, imagen: 'https://http2.mlstatic.com/D_NQ_NP_762649-MCO48688159791_122021-O.webp://encrypted-https://http2.mlstatic.com/D_NQ_NP_762649-MCO48688159791_122021-O.webp.gstatic.com/images?q=tbn:ANd9GcScxVEpoR3bIZFcvBesZIcdQgRusfmSuaDn9A&usqp=CAU' },
    { id: 1, nombre: 'Esfero negro', precio: 19.99, imagen: 'https://http2.mlstatic.com/D_NQ_NP_903205-MCO50688439646_072022-O.webp' },
    { id: 1, nombre: 'Pintura', precio: 19.99, imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYgocj9pGssW6sq3JzREt5949bfq6Zl17sKw&usqp=CAU' },
    { id: 1, nombre: 'Corrector', precio: 19.99, imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQb1RbSxFYWma4-Tge8PIX1jXc79mEGMRruWg&usqp=CAU' },
    { id: 1, nombre: 'Block de notas', precio: 19.99, imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQJTOnLQ5tMz2pveP4fqjNXGW10CzsXWdYKg&usqp=CAU' },
    { id: 1, nombre: 'Marcadores', precio: 19.99, imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQRpv4EQYBOASzGbSrwlpsNcVMuv12C03sRA&usqp=CAU' },
  ];

  const addToCart = (producto) => {
       // Aquí puedes implementar la lógica para agregar el producto al carrito
       console.log(`Producto añadido al carrito: ${producto.nombre}`);
      };

  return (
    <div>
      <Navbar className="mi-barra-de-navegacion" variant="dark" expand="lg">
        {/* Logo en el Navbar */}
        <Navbar.Brand href="#home">
          <img
            alt="Logo"
            src="https://cdn-icons-png.flaticon.com/256/8995/8995784.png" // Reemplaza con la URL de tu logo
            width="70"
            height="50"
            className="d-inline-block align-top"
          />{' '}
          Tienda Gran Colombia
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <NavItem href="/Inicio">Inicio</NavItem>
            <NavItem href="/Productos">Productos</NavItem>
            <NavItem href="/Cart_class">
              <BiCart size={30} />
            </NavItem>
          </Nav>
          <Nav className="ms-auto">
            <NavItem href="/" className="ml-auto">
              <strong>Cerrar sesión</strong>
            </NavItem>
          </Nav>
        </Navbar.Collapse>
      </Navbar>

      {/* Sección de productos */}
      <Container className="mt-4">
        <Row>
          {productos.map((producto) => (
            <Col key={producto.id} xs={12} sm={6} md={4} lg={3} className="mb-4">
              <Card>
                <Card.Img variant="top" src={producto.imagen} />
                <Card.Body>
                  <Card.Title>{producto.nombre}</Card.Title>
                  <Card.Text>Precio: ${producto.precio}</Card.Text>
                  <button className="btn btn-primary" onClick={() => addToCart(producto)}>
                    Añadir al carrito
                  </button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </div>
  );
};

const NavItem = ({ href, children }) => (
  <Nav.Link href={href}>{children}</Nav.Link>
);

export default Home;






